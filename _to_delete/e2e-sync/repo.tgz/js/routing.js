// Builds a walkable routing graph from the app's normalized road/path features
// (js/normalize.js's toRoadFeature/toPathFeature output, state.roads/state.paths) and finds
// shortest routes across it for the selected-target route line (drawSelectedRoute in
// js/renderer.js). Pure functions only -- no `state`/DOM access -- so this can be unit tested
// in isolation, matching js/normalize.js's own no-DOM-dependency convention.
//
// Coordinate space: graph nodes are the same projected world {x,y} points already sitting in
// state.roads[].segments / state.paths[].segments (see projectLonLat in index.html) -- callers
// snap and draw with those points directly, no extra conversion. Edge weights are real-world
// metres, computed once at build time from caller-supplied `toLatLon`/`distanceMetresFn`
// (index.html's unprojectPoint/distanceMetres) rather than raw Euclidean distance in world
// units, so the shortest path found is the shortest real walk.
//
// Junction topology: OSM ways sharing a junction share the exact same node coordinate from
// Overpass ("out geom"), so snapping every segment vertex to a coordinate-rounded key
// reconstructs the network without needing real OSM node IDs (normalize.js's segments are plain
// {x,y} arrays with no IDs attached). See ROUTING_NODE_PRECISION below for the rounding.

// World-unit coordinate rounding used to merge shared way endpoints into one graph node.
// 1e-6 degrees of longitude/Mercator-y is sub-millimetre at this projection's scale -- far
// tighter than any real floating-point noise, so it only ever merges genuinely coincident OSM
// nodes, never two distinct nearby junctions.
const ROUTING_NODE_PRECISION = 6;

// Highway/path types the router will cross, each mapped to a weight multiplier applied to its
// real distance. Every value is >=1: it *penalises* a type relative to a plain dedicated path,
// steering the search toward footpaths and quiet streets over busier roads when more than one
// way connects two points, without ever ruling a road out outright (some destinations are only
// reachable by street). motorway/trunk (and their _link variants) are deliberately absent --
// not walkable/safe, so those ways never enter the graph at all.
const ROUTING_TYPE_WEIGHTS = {
  path: 1, footway: 1, bridleway: 1, track: 1, byway: 1, cycleway: 1,
  pedestrian: 1.05, living_street: 1.05,
  residential: 1.15, service: 1.15, unclassified: 1.15,
  tertiary: 1.3, tertiary_link: 1.3,
  secondary: 1.6, secondary_link: 1.6,
  primary: 2, primary_link: 2,
};

// Alleys are highway=service ways additionally tagged service=alley -- OSM's way of marking a
// narrow pedestrian/service cut-through, distinct from a car park aisle or loading bay (also
// highway=service, but not walkable-shortcut in the same way). js/normalize.js's toRoadFeature
// already tells the two apart (roadType: "alley" vs "service") and js/renderer.js already
// draws alleys as the thinnest, faintest road line for the same reason -- so route them like a
// footpath too, rather than penalising them at the generic "service" rate.
function routingWeightForFeature(feature) {
  if (!feature) return null;
  const highway = feature.highway;
  if (highway === "service" && feature.service === "alley") return ROUTING_TYPE_WEIGHTS.path;
  return Object.prototype.hasOwnProperty.call(ROUTING_TYPE_WEIGHTS, highway)
    ? ROUTING_TYPE_WEIGHTS[highway]
    : null;
}

function routingNodeKey(point) {
  return point.x.toFixed(ROUTING_NODE_PRECISION) + "," + point.y.toFixed(ROUTING_NODE_PRECISION);
}

// Flood-fills `adjacency` to find every node's connected component, via a plain iterative
// stack (not recursion -- the biggest component here is 160k+ nodes deep) since OSM road/path
// data is never one single connected graph: small fenced-off fragments, mapped-but-unlinked
// station forecourts, and similar data gaps are common and expected (see findRoutePoints below
// for why the *size* of each node's component matters, not just its existence). Returns a
// `componentId` array parallel to `nodes`/`adjacency`, plus `largestComponentId` -- across this
// app's own regional data the largest component holds ~98.5% of all nodes, with every other
// component two orders of magnitude smaller, so "largest" reliably means "the real, walkable
// network" rather than a coin flip between comparably-sized regions.
function computeRoutingComponents(adjacency) {
  const n = adjacency.length;
  const componentId = new Int32Array(n).fill(-1);
  const componentSizes = [];
  for (let start = 0; start < n; start += 1) {
    if (componentId[start] !== -1) continue;
    const id = componentSizes.length;
    let size = 0;
    const stack = [start];
    componentId[start] = id;
    while (stack.length) {
      const u = stack.pop();
      size += 1;
      for (const edge of adjacency[u]) {
        if (componentId[edge.to] === -1) {
          componentId[edge.to] = id;
          stack.push(edge.to);
        }
      }
    }
    componentSizes.push(size);
  }
  let largestComponentId = 0;
  for (let i = 1; i < componentSizes.length; i += 1) {
    if (componentSizes[i] > componentSizes[largestComponentId]) largestComponentId = i;
  }
  return { componentId, componentSizes, largestComponentId };
}

// Shared graph-accumulation state used by both buildRoutingGraph (synchronous, for tests and
// small inputs) and buildRoutingGraphAsync (chunked/yielding, used by the app itself so a
// ~120k-node build never blocks a frame -- see ensureRoutingGraph in js/loader.js). Keeping one
// implementation of the actual graph-building logic behind this factory means the sync and
// async entry points can never drift apart into producing different graphs.
function createRoutingGraphBuilder(toLatLon, distanceMetresFn) {
  const nodeIndex = new Map();
  const nodes = [];
  const adjacency = [];

  function nodeId(point) {
    const key = routingNodeKey(point);
    let id = nodeIndex.get(key);
    if (id === undefined) {
      id = nodes.length;
      nodeIndex.set(key, id);
      nodes.push(point);
      adjacency.push([]);
    }
    return id;
  }

  function addEdge(fromId, toId, point1, point2, weight) {
    const a = toLatLon(point1);
    const b = toLatLon(point2);
    const metres = distanceMetresFn(a.latitude, a.longitude, b.latitude, b.longitude);
    if (!(metres > 0)) return; // skip zero-length / degenerate segments
    const cost = metres * weight;
    adjacency[fromId].push({ to: toId, metres, cost });
    adjacency[toId].push({ to: fromId, metres, cost });
  }

  return {
    // Adds every routable feature in `features` (a state.roads/state.paths-shaped array) to the
    // graph being built. Safe to call repeatedly with successive slices of a larger array --
    // that's exactly what buildRoutingGraphAsync below does to spread the work across ticks.
    addFeatures(features) {
      for (const feature of features || []) {
        const weight = routingWeightForFeature(feature);
        if (weight == null) continue;
        for (const segment of feature.segments || []) {
          let prevId = null;
          let prevPoint = null;
          for (const point of segment) {
            const id = nodeId(point);
            if (prevId !== null && prevId !== id) {
              addEdge(prevId, id, prevPoint, point, weight);
            }
            prevId = id;
            prevPoint = point;
          }
        }
      }
    },
    build() {
      const { componentId, componentSizes, largestComponentId } = computeRoutingComponents(adjacency);
      return { nodes, adjacency, componentId, componentSizes, largestComponentId };
    },
  };
}

// Builds the graph in one synchronous pass. `roadFeatures`/`pathFeatures` are state.roads/
// state.paths-shaped arrays (each with .highway and .segments -- see js/normalize.js).
// `toLatLon` converts a world {x,y} point back to {latitude,longitude} (index.html's
// unprojectPoint); `distanceMetresFn(lat1, lon1, lat2, lon2)` returns real metres between two
// lat/lon pairs (index.html's distanceMetres). Both are injected rather than imported so this
// module stays dependency-free for testing. Fine for tests and small inputs; the app itself
// uses buildRoutingGraphAsync below so the full ~28k-way regional network doesn't build inside
// a single blocking call.
function buildRoutingGraph(roadFeatures, pathFeatures, toLatLon, distanceMetresFn) {
  const builder = createRoutingGraphBuilder(toLatLon, distanceMetresFn);
  builder.addFeatures(roadFeatures);
  builder.addFeatures(pathFeatures);
  return builder.build();
}

// Same result as buildRoutingGraph, but processes `featureBatchSize` features at a time (default
// 500, matching loadMapData's own road-processing batch size in js/loader.js) and yields to the
// main thread with a zero-delay setTimeout between batches, so building the full regional graph
// (~28k ways) never blocks a frame or an in-flight input handler. Returns a Promise.
function buildRoutingGraphAsync(roadFeatures, pathFeatures, toLatLon, distanceMetresFn, featureBatchSize) {
  const batchSize = featureBatchSize || 500;
  const builder = createRoutingGraphBuilder(toLatLon, distanceMetresFn);
  const allFeatures = [...(roadFeatures || []), ...(pathFeatures || [])];
  const yieldToMainThread = () => new Promise((resolve) => setTimeout(resolve, 0));

  async function run() {
    for (let i = 0; i < allFeatures.length; i += batchSize) {
      builder.addFeatures(allFeatures.slice(i, i + batchSize));
      if (i + batchSize < allFeatures.length) await yieldToMainThread();
    }
    return builder.build();
  }

  return run();
}

// Finds the graph node nearest to `point` (plain nearest-vertex search, not nearest-point-on-
// edge -- OSM way vertices sit ~20m apart on average across this dataset, so the extra accuracy
// of projecting onto edges isn't worth the added complexity for a walking-directions line).
// Returns null only if the graph has no nodes at all (or, with `componentId` given, no nodes in
// that component). Pass `componentId` to restrict the search to one connected component -- see
// findRoutePoints below, which snaps to the graph's largest component specifically, so a target
// sitting a few metres from a small disconnected stub (a mapped-but-unlinked station forecourt
// footway is a real, recurring example) doesn't strand the search there instead of on the real,
// reachable network just slightly further away.
function nearestRoutingNode(graph, point, componentId, preferredDirection) {
  const nodes = graph && graph.nodes;
  if (!nodes || !nodes.length) return null;
  const componentIds = componentId != null ? graph.componentId : null;
  let bestId = -1;
  let bestScore = Infinity;
  
  // Vector from reference to destination (used for direction preference)
  const toDestX = point.x - (preferredDirection?.x || 0);
  const toDestY = point.y - (preferredDirection?.y || 0);
  const toDestLen = Math.sqrt(toDestX * toDestX + toDestY * toDestY);
  
  for (let i = 0; i < nodes.length; i += 1) {
    if (componentIds && componentIds[i] !== componentId) continue;
    const dx = nodes[i].x - point.x;
    const dy = nodes[i].y - point.y;
    const distSq = dx * dx + dy * dy;
    
    let score = distSq;
    
    // If we have a direction preference, apply a strong directional multiplier
    if (preferredDirection && toDestLen > 0) {
      // Dot product: positive means node is in roughly same direction as destination
      const dot = (nodes[i].x - preferredDirection.x) * toDestX + 
                  (nodes[i].y - preferredDirection.y) * toDestY;
      const cosAngle = dot / (Math.sqrt(distSq) * toDestLen);
      
      // Apply directional multiplier: nodes in the right direction get a bonus,
      // nodes behind or to the side get a large penalty. This makes direction a primary
      // factor in snap selection, not a secondary tiebreaker.
      // cosAngle ranges from -1 (behind) to 1 (directly ahead)
      // Convert to a multiplier: -1 -> 3x penalty, 0 -> 1x, 1 -> 0.3x bonus
      const directionMultiplier = Math.pow(Math.max(0.1, 1 - cosAngle), 1.5);
      score = distSq * directionMultiplier;
    }
    
    if (score < bestScore) {
      bestScore = score;
      bestId = i;
    }
  }
  if (bestId === -1) return null;
  return { nodeId: bestId, point: nodes[bestId] };
}

// Minimal binary min-heap keyed by priority, used by dijkstraPath below. Kept inline rather than
// a naive O(n) scan for the frontier -- the graph has 100k+ nodes (the full Epping Forest area's
// roads+paths), so an unindexed scan per pop would make every query far too slow.
function createRoutingHeap() {
  const items = [];
  function swap(i, j) { const t = items[i]; items[i] = items[j]; items[j] = t; }
  return {
    get size() { return items.length; },
    push(priority, value) {
      items.push({ priority, value });
      let i = items.length - 1;
      while (i > 0) {
        const parent = (i - 1) >> 1;
        if (items[parent].priority <= items[i].priority) break;
        swap(parent, i);
        i = parent;
      }
    },
    pop() {
      const top = items[0];
      const last = items.pop();
      if (items.length) {
        items[0] = last;
        let i = 0;
        for (;;) {
          const l = i * 2 + 1;
          const r = i * 2 + 2;
          let smallest = i;
          if (l < items.length && items[l].priority < items[smallest].priority) smallest = l;
          if (r < items.length && items[r].priority < items[smallest].priority) smallest = r;
          if (smallest === i) break;
          swap(smallest, i);
          i = smallest;
        }
      }
      return top;
    },
  };
}

// Dijkstra's algorithm from startNode to endNode over `graph`, prioritising each edge by
// `edge[priorityKey]` -- by default `.cost` (real metres * the type preference multiplier, see
// ROUTING_TYPE_WEIGHTS), which is what produces the footpath/quiet-street-preferring route
// findRoutePoints normally draws. Pass priorityKey "metres" to instead find the plain shortest
// real-world walk, ignoring the type preference entirely -- findRoutePoints below falls back to
// this when the preferred route is a pathological detour (see its own comment). Either way the
// path's actual `.metres` (real, unweighted distance) is reported alongside it, so callers can
// sanity-check the result against the straight-line distance without re-walking the path.
// Returns null when the two nodes aren't connected (the road/path network isn't one single
// connected component -- small fenced-off fragments exist, see spec-data-rendering.md).
function dijkstraPath(graph, startNode, endNode, priorityKey) {
  const key = priorityKey || "cost";
  const n = graph.adjacency.length;
  if (startNode < 0 || endNode < 0 || startNode >= n || endNode >= n) return null;
  const cost = new Float64Array(n).fill(Infinity);
  const metres = new Float64Array(n).fill(Infinity);
  const prev = new Int32Array(n).fill(-1);
  const visited = new Uint8Array(n);
  cost[startNode] = 0;
  metres[startNode] = 0;
  const heap = createRoutingHeap();
  heap.push(0, startNode);

  while (heap.size) {
    const { priority: d, value: u } = heap.pop();
    if (visited[u]) continue;
    visited[u] = 1;
    if (d > cost[u]) continue; // stale heap entry
    if (u === endNode) break; // shortest path to the target is finalised
    for (const edge of graph.adjacency[u]) {
      if (visited[edge.to]) continue;
      const nextCost = d + edge[key];
      if (nextCost < cost[edge.to]) {
        cost[edge.to] = nextCost;
        metres[edge.to] = metres[u] + edge.metres;
        prev[edge.to] = u;
        heap.push(nextCost, edge.to);
      }
    }
  }

  if (!Number.isFinite(cost[endNode])) return null;

  const nodeIds = [];
  for (let cur = endNode; cur !== -1; cur = prev[cur]) nodeIds.push(cur);
  nodeIds.reverse();
  return { nodeIds, metres: metres[endNode] };
}

// Top-level entry point: finds a walking route from `fromPoint` to `toPoint` (both world {x,y})
// across `graph`, and returns it as an array of world points ready to draw -- the real start and
// end points followed by the graph's node path in between -- or null when a sensible route
// can't be found, in which case the caller should fall back to a plain straight line:
//   - either point is further than options.maxSnapMetres from the nearest node in the graph's
//     largest connected component (there's no real, reachable path/road near it -- see below for
//     why "largest component" specifically, rather than just "nearest node anywhere"), or
//   - neither the type-weighted route nor the plain-shortest one (see below) comes in under
//     options.maxDetourRatio times the straight-line distance -- both points are on the real
//     network, but only reachable from each other via a pathologically long walk.
//
// Both points snap only onto the graph's largest component (computeRoutingComponents, computed
// once at build time), never onto whichever node happens to be geometrically nearest. Real OSM
// road/path data is never one single connected graph -- small fenced-off fragments, and mapped-
// but-unlinked station forecourt/platform footways, are common -- and since those fragments are
// two-plus orders of magnitude smaller than the real network here (confirmed against this app's
// own regional data: ~98.5% of all graph nodes sit in one component), a target a few metres from
// one of them is far better served by walking the extra distance onto the real network than by
// being snapped onto a two- or three-node dead end that goes nowhere. Snapping both ends to the
// same component also means they can never be "disconnected from each other" -- any two nodes in
// one connected component are reachable from each other by definition -- so that failure mode,
// which used to require a maxDetourRatio rejection to catch after the fact, is avoided upfront.
//
// The search itself runs twice at most. The first pass prioritises ROUTING_TYPE_WEIGHTS-weighted
// cost, same as ever, so a quiet footpath is still preferred over a busier road when the two are
// real-world comparable. But on a longer, multi-junction walk, a chain of individually-reasonable
// preferences for the quieter option at each junction can compound into a route that is, in
// aggregate, many times longer than a plain direct one would be -- reproduced against this app's
// own regional data (see test/forest-finds.test.js's "falls back to the plain-shortest route"
// test for a worked example and the exact numbers). Rejecting that outright and falling back to
// an as-the-crow-flies line is a worse experience than a real (if slightly less scenic) walking
// route, so when the weighted route fails the detour check, a second pass re-runs Dijkstra
// prioritising real distance (`priorityKey: "metres"`, ignoring the type preference entirely)
// and uses that route instead if it, in turn, passes the same check.
function findRoutePoints(graph, fromPoint, toPoint, options) {
  if (!graph || !graph.nodes || !graph.nodes.length) return null;
  const toLatLon = options.toLatLon;
  const distanceMetresFn = options.distanceMetresFn;
  const maxSnapMetres = options.maxSnapMetres != null ? options.maxSnapMetres : 100;
  const maxDetourRatio = options.maxDetourRatio != null ? options.maxDetourRatio : 4;

  const fromLatLon = toLatLon(fromPoint);
  const toLatLonValue = toLatLon(toPoint);
  const straightLineMetres = distanceMetresFn(
    fromLatLon.latitude, fromLatLon.longitude,
    toLatLonValue.latitude, toLatLonValue.longitude
  );
  if (!(straightLineMetres > 0)) return null;

  const mainComponent = graph.largestComponentId;
  // Snap user location with preference toward the destination
  // This prevents the user from snapping to a road node that's the wrong direction
  // (e.g., around a building instead of toward the destination)
  const fromSnap = nearestRoutingNode(graph, fromPoint, mainComponent, toPoint);
  const toSnap = nearestRoutingNode(graph, toPoint, mainComponent, fromSnap.point);

  if (!fromSnap || !toSnap || fromSnap.nodeId === toSnap.nodeId) return null;

  const fromSnapLatLon = toLatLon(fromSnap.point);
  const toSnapLatLon = toLatLon(toSnap.point);
  const fromSnapMetres = distanceMetresFn(
    fromLatLon.latitude, fromLatLon.longitude,
    fromSnapLatLon.latitude, fromSnapLatLon.longitude
  );
  const toSnapMetres = distanceMetresFn(
    toLatLonValue.latitude, toLatLonValue.longitude,
    toSnapLatLon.latitude, toSnapLatLon.longitude
  );
  if (fromSnapMetres > maxSnapMetres || toSnapMetres > maxSnapMetres) return null;

  let path = dijkstraPath(graph, fromSnap.nodeId, toSnap.nodeId);
  if (!path) return null;

  let routeMetres = path.metres + fromSnapMetres + toSnapMetres;
  if (routeMetres > straightLineMetres * maxDetourRatio) {
    const shortestPath = dijkstraPath(graph, fromSnap.nodeId, toSnap.nodeId, "metres");
    const shortestRouteMetres = shortestPath ? shortestPath.metres + fromSnapMetres + toSnapMetres : Infinity;
    if (shortestPath && shortestRouteMetres <= straightLineMetres * maxDetourRatio) {
      path = shortestPath;
      routeMetres = shortestRouteMetres;
    } else {
      return null;
    }
  }

  const points = path.nodeIds.map((id) => graph.nodes[id]);
  return [fromPoint, ...points, toPoint];
}
