@spec/agents.md
